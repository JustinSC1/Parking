const express = require('express');
const router = express.Router();
const parkingcontrolador = require('../controlador/parkingControlador');

router.get('/', parkingcontrolador.obtenerDatos);
router.post('/guardar', parkingcontrolador.crearRegisro);
router.put('/:placa', parkingcontrolador.actualizarDatos);
router.delete('/:placa', parkingcontrolador.eliminarDatos);

module.exports = router;