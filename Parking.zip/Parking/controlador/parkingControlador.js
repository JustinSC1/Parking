const modelo = require('../modelo/parkingModelo');

const obtenerDatos = (req, res) => {
    const parking = modelo.getAllData();
    res.json(parking)
};

const crearRegisro = (req, res) => {
    const {t1: idParqueo, t2: placa, t3: apartamento, t4: celda} = req.body;

    if (modelo.getDataById(idParqueo)) {
        return res.status(400).json({ error: 'Los datos ya estan registrados' });
    }

    const nuevo = {
        idParqueo,
        placa,
        apartamento,
        celda
    };

    const datosCreados = modelo.addParking(nuevo);
    res.status(201).json(datosCreados);
};

const actualizarDatos = (req, res) => {
    const id = req.params.id;
    const data = req.body;
    const actualizado = modelo.updateParking(id, data);
    if (!actualizado) {
        res.status(404).json({error: 'Datos no encontrados'});
    }
    res.json(actualizado);
};

const eliminarDatos = (req, res) => {
    const id = req.params.idParqueo;
    const eliminado = modelo.deleteParking(id);
    if (!eliminado) {
        return res.status(404).json({error: 'Datos no encontrados'});
    }
    res.json({mensaje: 'Datos eliminados', parqueo: eliminado});
};

module.exports = {
    obtenerDatos,
    crearRegisro,
    actualizarDatos,
    eliminarDatos
};