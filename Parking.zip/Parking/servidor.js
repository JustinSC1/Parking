const express = require('express');
const cors = require('cors');
const app = express();
const parkingrutas = require('./vista/parkingRutas');

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({extended: true}));

app.use('/parking', parkingrutas);

app.listen(3000, () => {
    console.log('Servidor escuchando en http://localhost:3000')
});