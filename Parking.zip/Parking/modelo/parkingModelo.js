let parking = [];

const getAllData = () => parking;

const getDataById = (idParqueo) => 
    parking.find(m => m.idParqueo === idParqueo);

const addParking = (parqueo) => {
    parking.push(parqueo);
    return parqueo;
};

const updateParking = (idParqueo, data) => {
    const index = parking.findIndex(m => m.idParqueo  === idParqueo);
    if (index === -1) return null;

    parking[index] = {...parking[index], ...data};
    return parking[index];
};

const deleteParking = (idParqueo) => {
    const index = parking.findIndex(m => m.idParqueo  === idParqueo);
    if (index === -1) return null;

    const eliminado = parking.splice(index, 1);
    return eliminado[0];
};

module.exports = {
    getAllData,
    getDataById,
    addParking,
    updateParking,
    deleteParking
};